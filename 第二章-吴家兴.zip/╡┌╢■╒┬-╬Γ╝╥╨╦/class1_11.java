package 第一课;

public class class1_11 {
    public static void main(String[] args){
        int a=150;
        int b=210;
        int c=165;

        int max=a>b?a:b;
        int max1=max>c?max:c;
        System.out.println("最高身高"+max1);
    }
}

