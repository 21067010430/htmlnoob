package 第一课;

public class class1_5 {
    public static void main(String[] args){
        System.out.println("Hello"+"World");
        System.out.println("hello"+23);
        System.out.println(23+"hello");

        System.out.println("hello"+2+3);
        System.out.println(2+3+"hello");
    }
}
