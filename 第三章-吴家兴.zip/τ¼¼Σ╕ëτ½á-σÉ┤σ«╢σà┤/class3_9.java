public class class3_9 {
    public static void main(String[] args){
        int i=1;
        int sum=0;
        while (i<=5){
            sum=sum+i;
            i=i+1;
        }
            System.out.println("sum="+sum);

    }
}
